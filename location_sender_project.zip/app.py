from flask import Flask, render_template, request, jsonify
from datetime import datetime, timezone
import json
import os

app = Flask(__name__)
DATA_FILE = "locations.json"

def save_location(data):
    records = []
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                records = json.load(f)
        except (json.JSONDecodeError, OSError):
            records = []

    data["received_at"] = datetime.now(timezone.utc).isoformat()
    records.append(data)

    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)

@app.route("/")
def index():
    return render_template("index.html")

@app.post("/location")
def location():
    data = request.get_json(silent=True) or {}

    try:
        latitude = float(data["latitude"])
        longitude = float(data["longitude"])
    except (KeyError, TypeError, ValueError):
        return jsonify({"ok": False, "error": "مختصات نامعتبر است."}), 400

    if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
        return jsonify({"ok": False, "error": "محدوده مختصات نامعتبر است."}), 400

    record = {
        "latitude": latitude,
        "longitude": longitude,
        "accuracy_m": data.get("accuracy")
    }
    save_location(record)

    maps_url = f"https://www.google.com/maps?q={latitude},{longitude}"
    return jsonify({"ok": True, "maps_url": maps_url})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
